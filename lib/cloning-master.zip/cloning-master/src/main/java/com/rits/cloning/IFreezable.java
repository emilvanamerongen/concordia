package com.rits.cloning;

/**
 * @author kostantinos.kougios
 *
 * 15 Nov 2010
 */
public interface IFreezable
{
	public boolean isFrozen();

}
