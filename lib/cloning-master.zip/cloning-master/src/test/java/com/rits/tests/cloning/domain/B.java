package com.rits.tests.cloning.domain;

/**
 * @author kostantinos.kougios
 *
 * 30 Nov 2009
 */
public class B extends A
{
	private int	y	= 7;

	public int getY()
	{
		return y;
	}

	public void setY(final int y)
	{
		this.y = y;
	}

}
